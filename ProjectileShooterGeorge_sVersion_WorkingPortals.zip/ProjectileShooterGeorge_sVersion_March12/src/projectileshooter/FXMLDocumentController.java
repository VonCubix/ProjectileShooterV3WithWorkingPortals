/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectileshooter;

import java.awt.Point;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author cstuser
 */
public class FXMLDocumentController implements Initializable {

    private double lastFrameTime = 0.0;

    @FXML
    private AnchorPane pane;

    @FXML
    private Label coordinates;

    @FXML
    private ImageView gunImage;

    @FXML
    private ImageView character;

    @FXML
    private RadioButton radioButtonFireGun;
    @FXML
    private RadioButton radioButtonIceGun;
    @FXML
    private RadioButton radioButtonAGGun;
    @FXML
    private RadioButton radioButtonPortalGun;
    
    @FXML
    private Button buttonClosePortals;
    
    @FXML
    private Button buttonCloseAntiGravity;

    //Local Variables
    ArrayList<Double> values = new ArrayList<Double>();
    public ArrayList<GameObject> objectList = new ArrayList<>();
    private ArrayList<Projectile> arrayListProjectiles = new ArrayList<>();

    private int counterProjectiles;
    private int counterBounces;

    //rectangles for detecting collisions with the edges of the game environment
    private Edge edgeRoof;
    private Edge edgeFloor;
    private Edge edgeLeftWall;
    private Edge edgeRightWall;
    
    private AntiGravity agLeftSide;
    private AntiGravity agRightSide;
    
    Bounds boundPortalIn;
    Bounds boundPortalOut;

    //Boolean to check if the projectile is within the bounds of an antigravity region
    private boolean isWithinAntiGravity = false;


    private Portal portalIn;
    private Portal portalOut;

    public  boolean portalInIsActive = false;
    public  boolean portalOutIsActive = false; 
    
    public boolean portalInIsLeftWall = false;
    public boolean portalOutIsLeftWall = false;
    
    public boolean portalInIsRightWall = false;
    public boolean portalOutIsRightWall = false;
    
    public boolean portalInIsRoof = false;
    public boolean portalOutIsRoof = false;
    
    public boolean portalInIsFloor = false;
    public boolean portalOutIsFloor = false;
    
    
    
    public boolean antiGravityIsActive = false;

    public Point mouseAim;
    public Point gunPivot;

    //used in the calculation of the angle of the gun and the projectile initial velocity
    double theta;

    //Variables for the mouse's position within the game environment
    private double mouseX;
    private double mouseY;

    private Vector velocityProjectile;
    private Vector acceleration;
    private Projectile projectile;

    //Final variables
    private final double PROJECTILE_RADIUS = 10; // Radius of the projectiles
    private final double PROJECTILE_VELOCITY = 500; //Magnitude of the projectile's velocity
    private final double GRAVITY = 50; //Magnitude of gravity
    
    private final int MAX_NUMBER_OF_BOUNCES = 3;
    
    private final double GUN_LENGTH = 150; //equvallent to gunImage.getFitWidth() / 2; (original value 243)
    
    //Values used by portals and antigravity
    private final double PORTAL_WIDTH = 30;
    private final double PORTAL_HEIGHT = 100;
    private final double AG_BORDERTHICKNESS = 40;
    private final double AG_DELTA_X = 150;
    
    private final double PORTAL_DELTA = 50;
    
    //Values that are used for corrections/compensations
    private final double ROTATION_PORTAL_ROOF = 270;
    private final double CORRECTION_PORTAL = -40;
    
    private final double ROTATION_PORTAL_LEFT = 180;
    
    private final double ROTATION_PORTAL_FLOOR = 90;
    
    
    //Values used for the location  of the character's shoulder for shooting location
    private final double SHOULDER_X = 125;
    private final double SHOULDER_Y = 725;

    public void addToPane(Node node) {
        pane.getChildren().add(node);
    }

    public void removeFromPane(Node node) {
        pane.getChildren().remove(node);
    }
    
    /*
    public double getIncidentAngle(Projectile proj)
    {
        if(proj.getVelocity())        
    }
    */

    @FXML
    public void mouseMoved(MouseEvent event) {
        mouseX = event.getSceneX();
        mouseY = (pane.getHeight() - event.getSceneY());

        mouseAim = new Point((int) mouseX, (int) mouseY);
        gunRotationAngle(mouseAim, gunPivot);

        coordinates.setText("MouseX: " + mouseX + "MouseY: " + mouseY);
    }

    @FXML
    public void mouseClicked(MouseEvent event) {

        acceleration = new Vector(0, GRAVITY);

        //Checks if the projectile is within the bounds of an antigravity region and inverts the gravity if it is. ---------------PROBABLY REMOVE---------------------
        if (isWithinAntiGravity) {
            acceleration = new Vector(0, -GRAVITY);
        }

        //Supplies the method with values for the mouse's "x" and "y" coordinates
        mouseX = event.getSceneX();
        mouseY = (pane.getHeight() - event.getSceneY());


        //---------Changes the type of projectile depending on the gun--------
        if (radioButtonFireGun.isSelected()) {
            projectile = new Projectile(new Vector(SHOULDER_X, SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "fire");
        }

        if (radioButtonIceGun.isSelected()) {
            projectile = new Projectile(new Vector(SHOULDER_X, SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "ice");
        }

        if (radioButtonAGGun.isSelected()) {
            if(antiGravityIsActive == true){
                closeAntiGravity();
                projectile = new Projectile(new Vector(SHOULDER_X, SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "antigravity");
            }            
            else
            {
                projectile = new Projectile(new Vector(SHOULDER_X, SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "antigravity");
            }
            
        }

        if (radioButtonPortalGun.isSelected()) {
            
            if(portalInIsActive && portalOutIsActive)
            {
                closePortal();
                projectile = new Projectile(new Vector(SHOULDER_X , SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "portalIn");
            }
            if(portalInIsActive == false){
                projectile = new Projectile(new Vector(SHOULDER_X , SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "portalIn");
            }else{
                projectile = new Projectile(new Vector(SHOULDER_X , SHOULDER_Y), new Vector(Math.cos(theta) * PROJECTILE_VELOCITY, -Math.sin(theta) * PROJECTILE_VELOCITY), acceleration, PROJECTILE_RADIUS, "portalOut");
            }
        }

        //This ensures that only one projectile can exist at one time and if it can exist, it adds it to the scene
        if (arrayListProjectiles.isEmpty()) {
            addToPane(projectile.getCircle());
            objectList.add(projectile);
            arrayListProjectiles.add(projectile);
        }
    }

    public void gunRotationAngle(Point mouseAim, Point gunPivot) {
        theta = Math.atan2(mouseAim.y - gunPivot.y, mouseAim.x - gunPivot.x);
        
        double angle = Math.toDegrees(theta);
        gunImage.setRotate(-angle);
    }

    //----------PORTAL AND ANTIGRAVITY BEHAVIOR METHODS------------

    //PORTALS
    public void openPortal()
    {        
        buttonClosePortals.setDisable(false);
                    
        if(portalInIsActive == false)
        {            
            portalIn = new Portal(new Vector(projectile.getPosition().getX(), projectile.getPosition().getY() + CORRECTION_PORTAL), PORTAL_WIDTH, PORTAL_HEIGHT);
            boundPortalIn = portalIn.getBounds();
            objectList.add(portalIn);
            addToPane(portalIn.getRectangle());
            portalIn.getRectangle().setFill(AssetManager.getPortalIn());
            portalInIsActive = true;
        }
        else
        {            
            portalOut = new Portal(new Vector(projectile.getPosition().getX(), projectile.getPosition().getY() + CORRECTION_PORTAL), PORTAL_WIDTH, PORTAL_HEIGHT);
            boundPortalOut = portalOut.getBounds();
            objectList.add(portalOut);
            addToPane(portalOut.getRectangle());
            portalOut.getRectangle().setFill(AssetManager.getPortalOut());
            portalOutIsActive = true;
        }
    }

    //Method that closes portals and should only be called when two portals are active
    public void closePortal()
    {        
        buttonClosePortals.setDisable(true);
        portalInIsActive = false;                
        objectList.remove(portalIn);
        removeFromPane(portalIn.getRectangle());
        
        portalOutIsActive = false;        
        objectList.remove(portalOut);
        removeFromPane(portalOut.getRectangle());
        
        portalInIsFloor = false;
        portalInIsRoof = false;
        portalInIsLeftWall = false;
        portalInIsRightWall = false;
        
        portalOutIsFloor = false;
        portalOutIsRoof = false;
        portalOutIsLeftWall = false;
        portalOutIsRightWall = false;
    }
    
    public void teleport(Projectile proj)            
    {
        //--------------------------------
        //----PortalIn is on the floor----
        //--------------------------------
        
        //PortalOut floor
        if(portalInIsFloor && portalOutIsFloor){
            proj.setPosition(portalOut.getPosition()); 
            proj.setVelocity(new Vector(proj.getVelocity().getX(), -proj.getVelocity().getY())); /////////////
        }
        
        //portalOut Roof
        if(portalInIsFloor && portalOutIsRoof){
            proj.setPosition(portalOut.getPosition());//////
        }
        
        //portalOut Left wall
        if(portalInIsFloor && portalOutIsLeftWall){
            proj.setPosition(portalOut.getPosition());
            if(proj.getVelocity().getX() < 0)
            {
                proj.setVelocity(new Vector(-proj.getVelocity().getX(), proj.getVelocity().getY())); ////////
            }
        }
        
        //PortalOut Right Wall
        if(portalInIsFloor && portalOutIsRightWall){
            proj.setPosition(portalOut.getPosition());
            if(proj.getVelocity().getX() > 0){
            proj.setVelocity(new Vector(-proj.getVelocity().getX(), -proj.getVelocity().getY()));/////////
            }
            else
            proj.setVelocity(proj.getVelocity());
        }
        
        //---------------------------------------
        //--------portalIn is on the Roof--------
        //---------------------------------------
        
        //PortalOut floor
        if(portalInIsRoof && portalOutIsFloor){
            proj.setPosition(portalOut.getPosition());  //////////////           
        }
        
        //portalOut Roof
        if(portalInIsRoof && portalOutIsRoof){
            proj.setPosition(portalOut.getPosition()); 
            proj.setVelocity(new Vector(proj.getVelocity().getX(), -proj.getVelocity().getY()));
        }
        
        //portalOut Left wall
        if(portalInIsRoof && portalOutIsLeftWall){
            proj.setPosition(portalOut.getPosition());
            if(proj.getVelocity().getX() < 0)
            {
                proj.setVelocity(new Vector(-proj.getVelocity().getX(), proj.getVelocity().getY()));
            }
            else{
                //just set the position
            }
        }
        
        //PortalOut Right Wall
        if(portalInIsRoof && portalOutIsRightWall){
            proj.setPosition(portalOut.getPosition());
            if(proj.getVelocity().getX() > 0){
            proj.setVelocity(new Vector(-proj.getVelocity().getX(), proj.getVelocity().getY()));
            }
            else 
            {
                //just set the position
            }
        }
        
        
        //---------------------------------------
        //------portalIn is on the LeftWall------
        //---------------------------------------
        
        //PortalOut floor
        if(portalInIsLeftWall && portalOutIsFloor){
            proj.setPosition(portalOut.getPosition());   
            
            if(proj.getVelocity().getY() > 0)
            {
                proj.setVelocity(new Vector(proj.getVelocity().getX(), -proj.getVelocity().getY()));
            }
            else
            {
                //just set the position
            }
        }
        
        //portalOut Roof
        if(portalInIsLeftWall && portalOutIsRoof){
            proj.setPosition(portalOut.getPosition()); 
            if(proj.getVelocity().getY() < 0){
            proj.setVelocity(new Vector(proj.getVelocity().getX(), -proj.getVelocity().getY()));
            }
            else
            {
                //just set the position
            }
        }
        
        //portalOut Left wall
        if(portalInIsLeftWall && portalOutIsLeftWall){
            proj.setPosition(portalOut.getPosition());
            proj.setVelocity(new Vector(-proj.getVelocity().getX(), proj.getVelocity().getY()));////////////////
        }
        
        //PortalOut Right Wall
        if(portalInIsLeftWall && portalOutIsRightWall){
            proj.setPosition(portalOut.getPosition());            
        }
        
        //------------------------------------------
        //------portalIn is on the RightWall--------
        //------------------------------------------
        
        //PortalOut floor
        if(portalInIsRightWall && portalOutIsFloor){
            proj.setPosition(portalOut.getPosition());
            if(proj.getVelocity().getY() > 0)
            {
                proj.setVelocity(new Vector(proj.getVelocity().getX(), -proj.getVelocity().getY()));
            }
            else
            {
                //just set the position
            }
        }
        
        //portalOut Roof
        if(portalInIsRightWall && portalOutIsRoof){
            proj.setPosition(portalOut.getPosition()); 
            
            if(proj.getVelocity().getY() < 0){
            proj.setVelocity(new Vector(proj.getVelocity().getX(), -proj.getVelocity().getY()));
            }
            else
            {
                //just set the position
            }            
        }
        
        //portalOut Left wall
        if(portalInIsRightWall && portalOutIsLeftWall){
            proj.setPosition(portalOut.getPosition());
            proj.setVelocity(new Vector(-proj.getVelocity().getX(), proj.getVelocity().getY()));
        }
        
        //PortalOut Right Wall
        if(portalInIsRightWall && portalOutIsRightWall){
            proj.setPosition(portalOut.getPosition());
            proj.setVelocity(new Vector(-proj.getVelocity().getX(), proj.getVelocity().getY()));
        }        
    }    

    //ANTIGRAVITY
    public void openAntiGravity()
    {        
        buttonCloseAntiGravity.setDisable(false);
        antiGravityIsActive = true;
        agLeftSide = new AntiGravity(new Vector(projectile.getCircle().getCenterX() - AG_DELTA_X, 0), AG_BORDERTHICKNESS, pane.getHeight());
        agLeftSide.getRectangle().setFill(AssetManager.getAntiGravitySide());
        objectList.add(agLeftSide);
        addToPane(agLeftSide.getRectangle());
        
        agRightSide = new AntiGravity(new Vector(projectile.getCircle().getCenterX() + AG_DELTA_X, 0), AG_BORDERTHICKNESS, pane.getHeight());
        agRightSide.getRectangle().setFill(AssetManager.getAntiGravitySide());
        objectList.add(agRightSide);
        addToPane(agRightSide.getRectangle());
    }
    
    public void closeAntiGravity()
    {        
        buttonCloseAntiGravity.setDisable(true);
        antiGravityIsActive = false;
        objectList.remove(agLeftSide);
        removeFromPane(agLeftSide.getRectangle());
        
        objectList.remove(agRightSide);
        removeFromPane(agRightSide.getRectangle());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lastFrameTime = 0.0f;
        long initialTime = System.nanoTime();

        AssetManager.preloadAllAssets();


        ToggleGroup group = new ToggleGroup();
        radioButtonFireGun.setToggleGroup(group);
        radioButtonIceGun.setToggleGroup(group);
        radioButtonAGGun.setToggleGroup(group);
        radioButtonPortalGun.setToggleGroup(group);
        
        buttonCloseAntiGravity.setDisable(true);
        buttonClosePortals.setDisable(true);


        //Image of MainCharacter
        character.setImage(AssetManager.getCharacterImage());

        //Image Gun
        //if(selectedGunType == "fire")
        gunImage.setImage(AssetManager.getGunFire_Img());
        radioButtonPortalGun.setSelected(true);

        gunPivot = new Point();
        gunPivot.setLocation(100, 100);

        //Creating Edge objects
        edgeFloor = new Edge(new Vector(0, pane.getPrefHeight() + 50), pane.getPrefWidth() + 50, 1);
        edgeRoof = new Edge(new Vector(0, 0), pane.getPrefWidth() + 50, 1);
        edgeLeftWall = new Edge(new Vector(0, 0), 1, pane.getPrefHeight() + 50);
        edgeRightWall = new Edge(new Vector(pane.getPrefWidth() + 50, 0), 1, pane.getPrefHeight() + 50);

        //Adding Edges to the pane so that collisions can be detected with the edge
        addToPane(edgeFloor.getRectangle());
        addToPane(edgeRoof.getRectangle());
        addToPane(edgeLeftWall.getRectangle());
        addToPane(edgeRightWall.getRectangle());

        //Adding edges to the objectList so that their existance within the program can be monitored
        objectList.add(edgeFloor);
        objectList.add(edgeRoof);
        objectList.add(edgeLeftWall);
        objectList.add(edgeRightWall);

        new AnimationTimer() {
            @Override
            public void handle(long now) {
                try {
                    double currentTime = (now - initialTime) / 1000000000.0;
                    double frameDeltaTime = currentTime - lastFrameTime;
                    lastFrameTime = currentTime;

                    for (GameObject obj : objectList) {
                        if (obj != null) {
                            obj.updateRectangle(frameDeltaTime);
                            obj.updateCircle(frameDeltaTime);
                        }
                    }
                } catch (Exception e) {}

                if(group.getSelectedToggle() == radioButtonFireGun){
                    gunImage.setImage(AssetManager.getGunFire_Img());
                }

                if(group.getSelectedToggle() == radioButtonIceGun){
                    gunImage.setImage(AssetManager.getGunIce_Img());
                }

                if(group.getSelectedToggle() == radioButtonAGGun){
                    gunImage.setImage(AssetManager.getGunAntiGravity_Img());
                }

                if(group.getSelectedToggle() == radioButtonPortalGun){
                    gunImage.setImage(AssetManager.getGunPortalIn_Img());
                }



                for (int i = 0; i < arrayListProjectiles.size(); i++) {
                    //AudioClip tempBounce = AssetManager.getBounce();  //---------------------SOUND IS BROKEN---------------
                    Projectile tempProjectile = arrayListProjectiles.get(i);

                    Circle projectileCircle = tempProjectile.getCircle();
                    Bounds boundProjectileCircle = projectileCircle.getBoundsInParent();

                    //SETTING BOUNDS

                    //Bound Floor
                    Rectangle rectangleEdgeFloor = edgeFloor.getRectangle();
                    Bounds boundRectangleEdgeFloor = rectangleEdgeFloor.getBoundsInParent();

                    //Bound Roof
                    Rectangle rectangleEdgeRoof = edgeRoof.getRectangle();
                    Bounds boundRectangleEdgeRoof = rectangleEdgeRoof.getBoundsInParent();

                    //Bound LeftWall
                    Rectangle rectangleEdgeLeftWall = edgeLeftWall.getRectangle();
                    Bounds boundRectangleEdgeLeftWall = rectangleEdgeLeftWall.getBoundsInParent();

                    //Bound RightWall
                    Rectangle rectangleEdgeRightWall = edgeRightWall.getRectangle();
                    Bounds boundRectangleEdgeRightWall = rectangleEdgeRightWall.getBoundsInParent();
                    
                    
                    //----------COLLISIONS--------


                        //FLOOR
                        if (boundProjectileCircle.intersects(boundRectangleEdgeFloor)) {
                            
                            //Check for fire and ice (floor)
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice"))
                            {
                                ++counterBounces;
                                //Moves projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX(), tempProjectile.getPosition().getY() - PROJECTILE_RADIUS));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(tempProjectile.getVelocity().getX(), -tempProjectile.getVelocity().getY()));
                            }

                            //Check for antigravity (floor)
                            if(tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {                                
                                openAntiGravity();
                                
                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                                //------TODO-------
                            }

                            //Check for portalIn (floor)
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal(); 
                                portalInIsFloor = true;
                                
                                portalIn.getRectangle().setRotate(ROTATION_PORTAL_FLOOR);

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut (floor)
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();
                                portalOutIsFloor = true;
                                
                                portalOut.getRectangle().setRotate(ROTATION_PORTAL_FLOOR);

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }
                        }

                        //ROOF
                        if (boundProjectileCircle.intersects(boundRectangleEdgeRoof)) {
                            
                            //Check fire and ice (roof)
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice"))
                            {
                                ++counterBounces;
                                //Moves the projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX(), tempProjectile.getPosition().getY() + PROJECTILE_RADIUS));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(tempProjectile.getVelocity().getX(), -tempProjectile.getVelocity().getY()));
                            }

                            //Check for antigravity (roof)
                            if(tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {
                                openAntiGravity();
                                
                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                                //------TODO-------
                            }

                            //Check for portalIn (roof)
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal();                                
                                portalInIsRoof = true;
                                
                                portalIn.getRectangle().setRotate(ROTATION_PORTAL_ROOF);

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut (roof)
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();
                                portalOutIsRoof = true;
                                
                                portalOut.getRectangle().setRotate(ROTATION_PORTAL_ROOF);

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }
                        }

                        //LEFT WALL
                        if(boundProjectileCircle.intersects(boundRectangleEdgeLeftWall)){
                            
                            //Check for fire, ice and antigravity (left wall)
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice") || tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {
                                ++counterBounces;
                                //Moves the projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX() + PROJECTILE_RADIUS, tempProjectile.getPosition().getY()));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(-tempProjectile.getVelocity().getX(), tempProjectile.getVelocity().getY()));
                            }

                            //Check for portalIn (left wall)
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal();
                                portalInIsLeftWall = true;
                                
                                portalIn.getRectangle().setRotate(ROTATION_PORTAL_LEFT);

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut (left wall)
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();
                                portalOutIsLeftWall = true;
                                
                                portalOut.getRectangle().setRotate(ROTATION_PORTAL_LEFT);
                                
                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }
                        }
                        //RIGHT WALL
                        if(boundProjectileCircle.intersects(boundRectangleEdgeRightWall)){

                            //check for fire, ice and antigravity (Right wall)
                            if(tempProjectile.getType().equalsIgnoreCase("fire") || tempProjectile.getType().equalsIgnoreCase("ice") || tempProjectile.getType().equalsIgnoreCase("antigravity"))
                            {
                                ++counterBounces;
                                //Moves the projectile away from edge by 1 radius
                                tempProjectile.setPosition(new Vector(tempProjectile.getPosition().getX() - PROJECTILE_RADIUS, tempProjectile.getPosition().getY()));

                                //Inverts the projectile's velocity
                                tempProjectile.setVelocity(new Vector(-tempProjectile.getVelocity().getX(), tempProjectile.getVelocity().getY()));
                            }

                            //Check for portalIn (Right wall)
                            if(tempProjectile.getType().equalsIgnoreCase("portalIn"))
                            {
                                openPortal();
                                portalInIsLeftWall = true;

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                            //Check for PortalOut (Right wall)
                            if(tempProjectile.getType().equalsIgnoreCase("portalOut"))
                            {
                                openPortal();
                                portalOutIsRightWall = true;

                                tempProjectile.setVelocity(new Vector(0,0));
                                objectList.remove(tempProjectile);
                                removeFromPane(tempProjectile.getCircle());
                                arrayListProjectiles.remove(0);
                            }

                        }
                        //-----------Big fkn mess------------
                        
                        //portalOut is on the floor
                        if(portalInIsActive && portalOutIsActive){
                            
                        if(boundProjectileCircle.intersects(boundPortalIn))
                        {
                            teleport(tempProjectile);
                        }
                            /*
                        if(boundProjectileCircle.intersects(boundPortalIn) && portalOut.getRectangle().getRotate() == ROTATION_PORTAL_FLOOR)
                        {
                            //portalIn is on the floor
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_FLOOR){
                                tempProjectile.setVelocity(new Vector(tempProjectile.velocity.getX(), -tempProjectile.getVelocity().getY()));                                                            
                                teleport(tempProjectile);
                            }
                            
                            //portalIn is on the Roof
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_ROOF){                                
                                teleport(tempProjectile);
                            }
                            
                            //portalIn is on the leftWall
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_LEFT){                                
                                teleport(tempProjectile);
                            }
                        }
                        
                        //portalOut in on the Roof
                        if(boundProjectileCircle.intersects(boundPortalIn) && portalOut.getRectangle().getRotate() == ROTATION_PORTAL_ROOF)
                        {
                            //portalIn is on the floor
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_FLOOR){                                                  
                                teleport(tempProjectile);
                            }
                            
                            //portalIn is on the Roof
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_ROOF){ 
                                tempProjectile.setVelocity(new Vector(tempProjectile.velocity.getX(), -tempProjectile.getVelocity().getY())); 
                                teleport(tempProjectile);
                            }
                            
                            //portalIn is on the leftWall
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_LEFT){                                
                                teleport(tempProjectile);
                            }
                        }
                        
                        //portalOut in on the left wall
                        if(boundProjectileCircle.intersects(boundPortalIn) && portalOut.getRectangle().getRotate() == ROTATION_PORTAL_LEFT)
                        {
                            //portalIn is on the floor
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_FLOOR){                                                  
                                teleport(tempProjectile);
                            }
                            
                            //portalIn is on the Roof
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_ROOF){ 
                                tempProjectile.setVelocity(new Vector(tempProjectile.velocity.getX(), -tempProjectile.getVelocity().getY())); 
                                teleport(tempProjectile);
                            }
                            
                            //portalIn is on the leftWall
                            if(portalIn.getRectangle().getRotate() == ROTATION_PORTAL_LEFT){                                
                                teleport(tempProjectile);
                            }
                        }
                        */
                        }
                        
                        if(antiGravityIsActive)
                        {
                            if(projectileCircle.getCenterX() > agLeftSide.getRectangle().getX() && projectileCircle.getCenterX() < agRightSide.getRectangle().getX())
                            {                        
                                projectile.setAcceleration(new Vector(0, -10*GRAVITY));
                            }else{
                                projectile.setAcceleration(new Vector(0, GRAVITY));
                            }
                        }

                        if (counterBounces == MAX_NUMBER_OF_BOUNCES) {
                            counterBounces = 0;
                            objectList.remove(arrayListProjectiles.get(0));
                            arrayListProjectiles.remove(0);
                            removeFromPane(tempProjectile.getCircle());
                        }
                        //tempBounce.play(); --------------THE SOUND DOESNT WORK
                     //Collision with Sides


                    projectile = tempProjectile;

                }//for (int i = 0; i < arrayListProjectiles.size(); i++)

            }//public void handle(long now)

        }.start();

    }

}
